﻿using DataAccessObjects.Models;
using Repositories.CarRepository;
using Repositories.CustomerRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BussinessObjects;
public class AdministratorBussiness
{
    public static List<Customer> GetCustomers(int pageName) =>
        CustomerRepository.GetMany(pageName, 10);

    public static List<CarInformation> GetCars(int pageName) =>
        CarRepository.GetMany(pageName, 10);

    public static UpdateCustomerErrors? AdministratorUpdateCustomer(Customer _customer)
    {
        var errors = new UpdateCustomerErrors()
        {
            CustomerIdError = CustomerBussiness.ValidateCustomerId(_customer.CustomerId),
            CustomerNameError = CustomerBussiness.ValidateCustomerName(_customer.CustomerName),
            CustomerBirthdayError = CustomerBussiness.ValidateCustomerBirthday(_customer.CustomerBirthday),
            EmailError = CustomerBussiness.ValidateEmail(_customer.Email),
            TelephoneError = CustomerBussiness.ValidateTelephone(_customer.Telephone),
            PasswordError = CustomerBussiness.ValidatePassword(_customer.Password),
        };

        if (!errors.NoError()) return errors;

        CustomerRepository.Update(_customer);

        return null;
    }

    public static UpdateCustomerErrors? AdministratorAddCustomer(Customer _customer)
    {
        var errors = new UpdateCustomerErrors()
        {
            CustomerIdError = CustomerBussiness.ValidateCustomerId(_customer.CustomerId),
            CustomerNameError = CustomerBussiness.ValidateCustomerName(_customer.CustomerName),
            CustomerBirthdayError = CustomerBussiness.ValidateCustomerBirthday(_customer.CustomerBirthday),
            EmailError = CustomerBussiness.ValidateEmail(_customer.Email),
            TelephoneError = CustomerBussiness.ValidateTelephone(_customer.Telephone),
            PasswordError = CustomerBussiness.ValidatePassword(_customer.Password),
        };

        if (!errors.NoError()) return errors;

        CustomerRepository.Add(_customer);

        return null;
    }

    public static string? ValidateCarId(int carId)
    {
        bool carExists = CarRepository.Get(carId) != null;

        if (!carExists)
        {
            return "Car with the provided Id does not exist.";
        }

        return null;
    }

    public static string? ValidateCarName(string? carName)
    {
        if (carName == null) return null;

        if (!Regex.IsMatch(carName, "^[A-Za-z0-9 ]{2,50}$"))
        {
            return "Car name must be between 2 and 50 characters and contain only letters and numbers.";
        }
        return null;
    }

    public static string? ValidateCarDescription(string? carDescription)
    {
        if (carDescription == null) return null;

        if (!Regex.IsMatch(carDescription, "^.{2,220}$"))
        {
            return "Car description must be between 9 and 12 characters.";
        }
        return null;
    }

    public static string? ValidateNumberOfDoors(int? numberOfDoors)
    {
        if (numberOfDoors == null) return null;

        if (numberOfDoors < 1 && numberOfDoors > 10)
        {
            return "Number of doors must be in between 1 and 10.";
        }
        return null;
    }

    public static string? ValidateSeatCapacity(int? seatCapacity)
    {
        if (seatCapacity == null) return null;

        if (seatCapacity < 1 && seatCapacity > 100)
        {
            return "Seat capacity must be in between 1 and 100.";
        }
        return null;
    }

    public static string? ValidateFuelType(string? fuelType)
    {
        if (fuelType == null) return null;

        if (Regex.IsMatch(fuelType, "^.{2,20}$"))
        {
            return "Fuel type must be between 2 and 20 characters.";
        }
        return null;
    }

    public static string? ValidateYear(int? year)
    {
        if (year == null) return null;

        if (year > new DateOnly().Year)
        {
            return "Year must not be exceed than the current year.";
        }
        return null;
    }

    public static string? ValidateCarRentingPricePerDay(decimal? price)
    {
        if (price == null) return null;

        if (price <= 0)
        {
            return "Price must be higher than 0.";
        }
        return null;
    }

    public static UpdateCarErrors? AdministratorAddCar(CarInformation _car)
    {
        var errors = new UpdateCarErrors()
        {
            CarNameError = ValidateCarName(_car.CarName),
            CarDescriptionError = ValidateCarDescription(_car.CarDescription),
            CarRentingPricePerDayError = ValidateCarRentingPricePerDay(_car.CarRentingPricePerDay),
            FuelTypeError = ValidateFuelType(_car.FuelType),
            NumberOfDoorsError = ValidateNumberOfDoors(_car.NumberOfDoors),
            SeatingCapacityError = ValidateSeatCapacity(_car.SeatingCapacity),
            YearError = ValidateYear(_car.Year)
        };

        if (!errors.NoError()) return errors;

        CarRepository.Add(_car);

        return null;
    }
}

public class UpdateCarErrors
{
    public string? CarNameError { get; set; }
    public string? CarDescriptionError { get; set; }
    public string? NumberOfDoorsError { get; set; }
    public string? SeatingCapacityError { get; set; }
    public string? FuelTypeError { get; set; }
    public string? YearError { get; set; }
    public string? CarRentingPricePerDayError { get; set; }

    public bool NoError()
    {
        return CarNameError == null &&
            CarDescriptionError == null &&
            NumberOfDoorsError == null &&
            SeatingCapacityError == null &&
            FuelTypeError == null &&
            YearError == null &&
            CarRentingPricePerDayError == null;
    }
}
