﻿namespace DAO
{
    public class Class1
    {

    }
}