﻿using BussinessObjects;
using DataAccessObjects.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFView
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class ManageCustomersPage : Page
    {
        private int _currentPage;
        public ManageCustomersPage()
        {
            InitializeComponent();

            _currentPage = 1;

            RenderCustomerList();
        }

        private void OnAdd(object sender, RoutedEventArgs e)
        {
            var dialog = new AddUpdateCustomerWindow(true).ShowDialog();
            if (dialog!.Value) RenderCustomerList();
        }

        private void RenderCustomerList()
        {
            if (CustomerList.Rows.Count > 1)
            {
               
                for (int i = CustomerList.Rows.Count - 1; i > 0; i--)
                {
                    CustomerList.Rows.RemoveAt(i);
                }
            }
            var customerList = AdministratorBussiness.GetCustomers(_currentPage);

                foreach (var customer in customerList)
                {
                    var row = new TableRow();

                    var cell1 = new TableCell();
                    cell1.BorderBrush = Brushes.Black;
                    cell1.BorderThickness = new Thickness(1, 0, 1, 1);
                    cell1.Blocks.Add(new Paragraph(new Run(customer.CustomerId.ToString()))
                    {
                        Margin = Margin = new Thickness(5)
                    });
                    cell1.TextAlignment = TextAlignment.Center;

                    var cell2 = new TableCell();
                    cell2.BorderBrush = Brushes.Black;
                    cell2.BorderThickness = new Thickness(0, 0, 1, 1);
                    cell2.Blocks.Add(new Paragraph(new Run(customer.CustomerName))
                    {
                        Margin = Margin = new Thickness(5)
                    });
                    cell2.TextAlignment = TextAlignment.Center;

                    var cell3 = new TableCell();
                    cell3.BorderBrush = Brushes.Black;
                    cell3.BorderThickness = new Thickness(0, 0, 1, 1);
                    cell3.Blocks.Add(new Paragraph(new Run(customer.Telephone!.ToString()))
                    {
                        Margin = Margin = new Thickness(5)
                    });
                    cell3.TextAlignment = TextAlignment.Center;

                    var cell4 = new TableCell();
                    cell4.BorderBrush = Brushes.Black;
                    cell4.BorderThickness = new Thickness(0, 0, 1, 1);
                    cell4.Blocks.Add(new Paragraph(new Run(customer.Email))
                    {
                        Margin = Margin = new Thickness(5)
                    });
                    cell4.TextAlignment = TextAlignment.Center;

                    var cell5 = new TableCell();
                    cell5.BorderBrush = Brushes.Black;
                    cell5.BorderThickness = new Thickness(0, 0, 1, 1);
                    cell5.Blocks.Add(new Paragraph(new Run(DateOnly.FromDateTime(customer.CustomerBirthday!.Value).ToString()))
                    {
                        Margin = Margin = new Thickness(5)
                    });
                    cell5.TextAlignment = TextAlignment.Center;

                    var cell6 = new TableCell();
                cell6.BorderBrush = Brushes.Black;
                cell6.BorderThickness = new Thickness(0, 0, 1, 1);
                cell6.Blocks.Add(new Paragraph(new Run(customer.CustomerStatus == 1 ? "Yes" : "No"))
                {
                    Margin = Margin = new Thickness(5)
                });
                cell6.TextAlignment = TextAlignment.Center;

                var cell7 = new TableCell();
                cell7.BorderBrush = Brushes.Black;
                cell7.BorderThickness = new Thickness(0, 0, 1, 1);
                    var button1 = new Button()
                    {
                        Content = "Update",
                        Margin = Margin = new Thickness(5)
                    };

                    button1.Click += (object sender, RoutedEventArgs e) =>
                    {
                        var dialog = new AddUpdateCustomerWindow(false, customer).ShowDialog();
                        if (dialog!.Value) RenderCustomerList();
                    };
                cell7.Blocks.Add(new BlockUIContainer(button1));
                cell7.TextAlignment = TextAlignment.Center;

                var cell8 = new TableCell();
                cell8.BorderBrush = Brushes.Black;
                cell8.BorderThickness = new Thickness(0, 0, 1, 1);
                var button2 = new Button()
                {
                    Content = "Delete",
                    Margin = Margin = new Thickness(5)
                };

                button2.Click += (object sender, RoutedEventArgs e) =>
                {
                };
                cell8.Blocks.Add(new BlockUIContainer(button2));
                cell8.TextAlignment = TextAlignment.Center;

                    row.Cells.Add(cell1);
                    row.Cells.Add(cell2);
                    row.Cells.Add(cell3);
                    row.Cells.Add(cell4);
                    row.Cells.Add(cell5);
                    row.Cells.Add(cell6);
                    row.Cells.Add(cell7);
                    row.Cells.Add(cell8);

                CustomerList.Rows.Add(row);
            }
        }
    }
}
