﻿using DataAccessObjects.DAOs;
using DataAccessObjects.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.CarRepository
{
    public class CarRepository : ICarRepository
    {
        public static bool Add(CarInformation entity) 
            => CarDAO.Instance.AddCar(entity);

        public static CarInformation? Get(int id)
        {
            throw new NotImplementedException();
        }

        public static List<CarInformation> GetMany(int pageNumber, int pageSize)
        {
            throw new NotImplementedException();
        }

        public static int GetPages(int pageSize)
        {
            throw new NotImplementedException();
        }

        public static bool Update(CarInformation entity)
            => CarDAO.Instance.UpdateCar(entity);
    }
}
